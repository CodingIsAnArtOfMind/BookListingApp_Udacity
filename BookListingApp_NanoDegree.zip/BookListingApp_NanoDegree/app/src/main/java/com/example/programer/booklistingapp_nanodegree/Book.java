package com.example.programer.booklistingapp_nanodegree;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by #Programer on 3/9/2018.
 */

public class Book implements Parcelable {
    public static final Creator<Book> CREATOR = new Creator<Book>() {
        @Override
        public Book createFromParcel(Parcel in) {
            return new Book(in);
        }

        @Override
        public Book[] newArray(int size) {
            return new Book[size];
        }
    };
    String author;
    String title;

    public Book(String author, String title) {
        this.author = author;
        this.title = title;
    }

    protected Book(Parcel in) {
        author = in.readString();
        title = in.readString();
    }

    public String getAuthor() {
        return author;
    }

    public String getTitle() {
        return title;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(author);
        parcel.writeString(title);
    }
}
